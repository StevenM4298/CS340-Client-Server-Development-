# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'MathiasCS340' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient(f"mongodb://{USER}:{PASS}@{HOST}:{PORT}")
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None:
            result = self.collection.insert_one(data)
            return True
        else:
            return False

    # Create method to implement the R in CRUD.
    def read(self, query):
        try:
            documents = list(self.collection.find(query))
            return documents if documents else []
        except Exception as e:
            print(f"Error reading from database: {e}")
            return []

    # Update method to implement the U in CRUD
    def update (self, query, update_values):
        if query is None or update_values is None:
            return 0
        try:
            result = self.collection.update_many(query, update_values)
            return result.modified_count
        except Exception as e:
            print(f"Error updating: {e}")
            return 0

    # Delete method to implement the D in CRUD
    def delete(self, query):
        if query is None:
            return 0
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Error deleting: {e}")
            return 0

